﻿import {Component} from '@angular/core';

@Component({
    selector: 'mm-movies',
    templateUrl: 'app/movies/movie-list.component.html'
})

export class MovieListComponent {
    pageTitle: string = 'Movie List';
    movies: any[] = [
        {
            "movieId": 2,
            "movieName": "Titanic",
            "movieStar": "DiCaprio",
            "releaseDate": "3/13/2016",
            "price": 16.00,
            "starRating": 4.2,
            "imageUrl": "http://openclipart.org/image/300px/svg_to_png/26215/Anonymous_Leaf_Rake.png"
        },
        {
            "movieId": 3,
            "movieName": "Jaws",
            "movieStar": "Shaw",
            "releaseDate": "4/13/2016",
            "price": 16.00,
            "starRating": 4.8,
            "imageUrl": "http://openclipart.org/image/300px/svg_to_png/58471/garden_cart.png"
        }
    ];
}
