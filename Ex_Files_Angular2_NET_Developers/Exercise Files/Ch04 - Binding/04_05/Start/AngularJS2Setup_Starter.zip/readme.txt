This exercise project was previously missing but recently added to course. 

Updated Jaws URL in "\app\movies\movie-list.component.ts" file.