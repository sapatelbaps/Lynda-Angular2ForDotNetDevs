﻿import { Component, OnChanges} from '@angular/core';

@Component({
    selector: 'md-review',
    templateUrl: 'app/shared/review.component.html',
    styleUrls: ['app/shared/review.component.css']
})
export class ReviewComponent implements OnChanges{
    rating: number = 4;
    reviewWidth: number; // calculated onChange

    ngOnChanges(): void {
        this.reviewWidth = this.rating * 86 / 5;
    }

}